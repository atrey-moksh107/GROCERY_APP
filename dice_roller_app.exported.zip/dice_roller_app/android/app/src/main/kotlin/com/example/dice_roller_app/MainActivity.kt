package com.example.dice_roller_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
